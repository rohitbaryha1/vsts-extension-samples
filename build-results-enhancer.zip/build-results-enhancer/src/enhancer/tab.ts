import Controls = require("VSS/Controls");
import VSS_Service = require("VSS/Service");
import TFS_Build_Contracts = require("TFS/Build/Contracts");
import TFS_Build_Extension_Contracts = require("TFS/Build/ExtensionContracts");
import DT_Client = require("TFS/DistributedTask/TaskRestClient");

export class InfoTab extends Controls.BaseControl {	
	constructor() {
		super();
	}
		
	public initialize(): void {
		super.initialize();
		// Get configuration that's shared between extension and the extension host
		var sharedConfig: TFS_Build_Extension_Contracts.IBuildResultsViewExtensionConfig = VSS.getConfiguration();
		var vsoContext = VSS.getWebContext();
		if(sharedConfig) {
			// register your extension with host through callback
			sharedConfig.onBuildChanged((build: TFS_Build_Contracts.Build) => {
				this._initBuildInfo(build);	
				var taskClient = DT_Client.getClient();

				taskClient.getPlanAttachments(vsoContext.project.id, "build", build.orchestrationPlan.planId, "FortifyRiskReport").then((taskAttachments) => {
						if (taskAttachments.length === 1) {
						$(".risk-report-message").remove();
						var recId = taskAttachments[0].recordId;
						var timelineId = taskAttachments[0].timelineId;
						var link = taskAttachments[0]._links.self.href;
						var attachmentName = taskAttachments[0].name;

						$(".risk-report").append(" : ");
						$(".risk-report").append(attachmentName);
						$(".risk-report").append(" : ");
						$(".risk-report").append(link);
						$(".risk-report").append(" : ");
						$(".risk-report").append(timelineId);
						$(".risk-report").append(" : ");
						$(".risk-report").append(recId);

						taskClient.getAttachmentContent(vsoContext.project.id, "build", build.orchestrationPlan.planId, timelineId, recId, "FortifyRiskReport", attachmentName).then((attachementContent) => {
							$(".risk-report").append(" <br> ");
							$(".risk-report").append(" inside function ");

							function arrayBufferToString(buffer) {
								var arr = new Uint8Array(buffer);
								var str = String.fromCharCode.apply(String, arr);
								return str;
							}

							var summaryPageData = arrayBufferToString(attachementContent);
							var riskObject = JSON.parse(summaryPageData.replace(/[\u200B-\u200D\uFEFF]/g, ''));
							$(".risk-report").append(riskObject);

							var projectVersion = "<div class='project-version'><span>" +
								"<a href='" + riskObject.data.projectLink + "' target='_blank'>" + riskObject.projectName + "</a></span>" +
								"<span class='project-version-separator'><i class='fa fa-caret-right'></i></span><span>" +
								"<a href='" + riskObject.projectVersionLink + "' target='_blank'>" + riskObject.projectVersion + "</a></span></div>"

							$(".risk-report").append(projectVersion);

							// do some thing here
							// see how to get auth https://www.visualstudio.com/en-us/docs/report/analytics/building-extension-against-analytics-service

						});
					}
				});
			});
		}		
	}
	
	private _initBuildInfo(build: TFS_Build_Contracts.Build) {
		
	}
}

InfoTab.enhance(InfoTab, $(".fortify-report"), {});

// Notify the parent frame that the host has been loaded
VSS.notifyLoadSucceeded();

	
